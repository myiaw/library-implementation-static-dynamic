#include "libXPO.h"
#include <ctype.h>

float divide(float num1, float num2) {
    return num1 / num2;
}
char* upperString(char* str){
    while (*str++ = toupper(*str));
}