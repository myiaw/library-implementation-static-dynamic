#ifndef STATIC_LIBXPO_H
#define STATIC_LIBXPO_H

#include <stdint.h>
#include <stdlib.h>

float divide(float num1, float num2);
char* upperString(char* str);

#endif //STATIC_LIBXPO_H
